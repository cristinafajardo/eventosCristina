<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Input;
use DB;
use Validator;
use App\Usuario;
use Session;


class UsuariosController extends Controller
{
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
        public function index()
        {
            //
        }

        /**
         * Show the form for creating a new resource.
         *
         * @return \Illuminate\Http\Response
         */
        public function create() //muestra vista para registarse
        {
            return view('registro');
        }

        /**
         * Store a newly created resource in storage.
         *
         * @param  \Illuminate\Http\Request  $request
         * @return \Illuminate\Http\Response
         */
        public function store(Request $request) //inserto usuario en bd, a traves de "registro"
        {
            
            \App\Usuario::create([
                'username' => $request['username'],
                'email' => $request['email'],
                'password' => $request['pass'],
                'apellido' => $request['apellido'],
                'sexo' => $request['sexo'],
                'provincia' => $request['provincia'],
                'ciudad' => $request['ciudad'],

            ]);
            return view('login');
        }

        public function login(){ //muestra la vista de login
            return view('login');
        }
        
        public function post_login(){ //comprueba que exista el usuario y redirecciona a "miseventos" si esta ok.
           /* $input = Input::all();
            $rules = [
                'Email' => 'required|exists:usuarios,Email',
                'password' => 'required',
            ];
            $validator = Validator::make($input, $rules);
            if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator);
            }
            else
            {
                $email = input::Get('Email');
                $password = input::Get('password');
                $usuario = DB::Table('usuarios')->where('email', $email)->first();
                if ($usuario->password==$password) {
                    
                    return view('misEventos');
                }
                else
                {
                    return redirect()->back();
                }
            }*/
            $input = Input::all();
         $rules = [
                'Email' => 'required|exists:usuarios,Email',
                'password' => 'required',
            ];
        $validator = Validator::make($input, $rules);
        if($validator->fails())
        {
            return redirect()->back()->withErrors($validator);
        }
        else
        {
           $email = input::Get('Email');
                $password = input::Get('password');
                $usuario = DB::Table('usuarios')->where('email', $email)->first();
            if($usuario) 
            {
                //if($password = Usuario::where('password', '=', $password)->first()) //esta mal porque le asigna a $password una fila que contenga una clave valida (culaquiera) y auroriza
                if ($usuario->password == $password)
                {
                    //mi sesión va a tener un usuario_id y un usuario_username , los valores se los asigna capturando los datos de la tupla $usuario
                    Session::put('usuario_id', $usuario->id);
                    Session::put('usuario_username', $usuario->username);
                    Session::put('usuario_email', $usuario->email);                 
                    return view('misEventos');
                }
                else
                {
                    return view('/login');
                }
            }
            else
            {
                       return view('/login');
            }
        }
        }

        public function logout()
    {
        Session::flush();
         return view('/index');


    }
        /**
         * Display the specified resource.
         *
         * @param  int  $id
         * @return \Illuminate\Http\Response
         */
        public function show($id)
        {
            //
        }

        /**
         * Show the form for editing the specified resource.
         *
         * @param  int  $id
         * @return \Illuminate\Http\Response
         */
        public function edit($id)
        {
            //
        }

        /**
         * Update the specified resource in storage.
         *
         * @param  \Illuminate\Http\Request  $request
         * @param  int  $id
         * @return \Illuminate\Http\Response
         */
        public function update(Request $request, $id)
        {
            //
        }

        /**
         * Remove the specified resource from storage.
         *
         * @param  int  $id
         * @return \Illuminate\Http\Response
         */
        public function destroy($id)
        {
            //
        }	

         public function perfil() //muestra vista con datos del perfil creado en registrarme
        {
            return view('perfil');
        }
}
