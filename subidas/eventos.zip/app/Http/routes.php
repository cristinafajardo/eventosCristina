<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/*INDEX */
Route::get('index', 'DescripcionesController@index');
/*QUE ES */
Route::get('que', 'DescripcionesController@que');
/*QUIENES SOMOS */
Route::get('quienes', 'DescripcionesController@quienes');
/*CONTACTO */
Route::get('contacto', 'DescripcionesController@contacto');
Route::resource('contacto', 'ContactoController@store');

/*REGISTRO */
//Route::resource('usuarios', 'UsuariosController');
Route::get('registro', 'UsuariosController@create');
Route::post('registro', 'UsuariosController@store');


/*LOGIN */
Route::get('login', 'UsuariosController@login');
Route::post('login','UsuariosController@post_login');
Route::get('logout', 'UsuariosController@logout');
Route::get('perfil', 'UsuariosController@perfil');





/*ORGANIZA EVENTO */
Route::get('organizaEvento', function () {
    return view('organizaEvento');
});
Route::post('organizaEvento', 'EventosController@store');

/*MIS EVENTOS */
Route::get('misEventos', function () {
    return view('misEventos');
});
/**Google maps*/
Route::get('/gmaps', ['as ' => 'gmaps', 'uses' => 'GmapsController@index']);

Route::get('mapahdp', function () {
    return view('mapahdp');
});

