@extends('admin.template.layout')
@section('title')
   Organizar Evento
@endsection
@section('content')
<script src="{{ asset('js/listaCerrada.js') }}"></script>
<script src="{{ asset('js/cuentas.js') }}"></script> 


<h1>Nuevo evento</h1>
<div class="container">
	{!!Form::open(['method' => 'POST', 'class' => 'form-horizontal'])!!}
      <fieldset>
          <legend>Datos evento</legend>
          <div class="form-group">
          	 <label for="nombre" class="col-lg-2 control-label">Nombre del evento</label>
			  <div class="col-md-10">
			  	   {!!Form::text('nombre', '', ['class' => 'form-control','required'])!!}
				   <span class="help-block">{{ $errors->first('nombre') }}</span>
			  </div>
	      </div>
	      <div class="form-group">
	      	  <label for="lugar" class="col-lg-2 control-label">Lugar</label>
			  <div class="col-md-10">
			  	   {!!Form::text('lugar', '', ['class' => 'form-control','required'])!!}
				   <span class="help-block">{{ $errors->first('lugar') }}</span>
			  </div>
		  </div>
	      <div class="form-group">
		   	{!!Form::label('Fecha','',array('class'=>'col-lg-2 control-label'))!!}
				<div class="col-lg-10">
				{!! Form::input('date','fecha','',array( 'date_format' => 'yyyy-mm-dd')) !!}
				<!--Form::text('fecha','',array('class'=>'form-control','class'=>'input-append date','data-date-format'=>'dd-mm-yyyy'))-->
				</div>
				<span class="add-on"><i class="icon-th"></i></span>
	      </div>	
	      <div class="form-group">
		   	{!!Form::label('Hora','',array('class'=>'col-lg-2 control-label'))!!}
						<div class="col-lg-10">
						{!! Form::input('time', 'hora','',array( 'time_format' => 'HH:mm:ss')) !!}
						<!--Form::text('hora','',array('class'=>'form-control')) -->
						</div>
	      </div>	
		  <div class="form-group">
		  	  <label for="descripcion" class="col-lg-2 control-label">Descripción del evento</label>
		      <div class="col-md-10">
			  	   {!!Form::textarea('descripcion', '', ['class' => 'form-control','required'])!!}
				   <span class="help-block">{{ $errors->first('descripcion') }}</span>
		      </div>
		    <!--  <label for="textArea" class="col-lg-2 control-label">Descripcion del evento</label>
		     <div class="col-lg-10">
		       <textarea class="form-control" rows="3" id="textArea"></textarea>
		       <span class="help-block"></span>
		     </div> -->
		  </div>
		  <div class="form-group">
		  	  <label for="mayores" class="col-lg-2 control-label">Adultos</label>
		      <div class="col-md-2">
			  	   {!!Form::number('mayores', '', ['class' => 'form-control','required'])!!}
				   <span class="help-block">{{ $errors->first('descripcion') }}</span>
		      </div>
		      <label for="menores" class="col-lg-2 control-label">Niños</label>
		      <div class="col-md-2">
			  	   {!!Form::number('menores', '', ['class' => 'form-control','required'])!!}
				   <span class="help-block">{{ $errors->first('descripcion') }}</span>
		      </div>
		  </div>
		  <!-- GMAPS -->
		  <div  class="form-group">
		  	 @include('includes.mapahdp') 
			     
		  </div>
		  <div class="form-group">
	      <div class="col-lg-10 col-lg-offset-2">
	        <button type="reset" class="btn btn-default">Cancelar</button>
	       {!!Form::submit('Crear Evento',['id'=>'crearEvento','class' => 'btn btn-primary'])!!}
	      </div>
	    </div>
	    <br><br><br>
      </fieldset>
      <fieldset>
	  		<legend>Invitados</legend>
	  		<div class="checkbox">
	          <label>
	            <input type="checkbox" id='listaCerrada' onClick="cerrado();"> Lista cerrada
	          </label>
	        </div>
	  		<ul class="nav navbar-right">  
	  			<a href="#" class="btn btn-warning" data-toggle='modal' data-target='#popupNuevoInvitado' id='+invitado'>Agregar invitado +</a><br><br><br>
			</ul>
			<div class="modal" id='popupNuevoInvitado' role='dialog'>
			  <div class="modal-dialog">
			    <div class="modal-content">
			      <div class="modal-header">
				        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				        <h4 class="modal-title">Nuevo Invitado</h4>
			      </div>
			      <div class="modal-body">
			         {!!Form::open(array('method' => 'POST', 'url' => '/itempop', 'role' => 'form'))!!}
						  <div class="form-group">
		                      <label for="inputNombre" class="col-lg-6 control-label">Nombre </label>   
		                           <input class="form-control" id="inputNombre" placeholder="Nombre" type="text" name="nombre">
		                                      
		                  </div>
						  <div class="form-group">
		                    <label for="inputEmail" class="col-lg-6 control-label">Email
		                        <input class="form-control" id="inputEmail" placeholder="Email del invitado" type="email" name="mail">
		                    </label>                   
		                  </div>
						  <div class="form-group">
							<label class="col-lg-2 control-label">ROL:</label>
								<div class="col-lg-2">
								    <label class="radio-inline">
									<input type="radio" name="rol" value="invitado" checked="checked">Invitado</label>
						       </div>
							   <div class="col-lg-2">
							       <label class="radio-inline">
							       <input type="radio" name="rol" value="creador">Organizador</label>
		            	       </div>
		            	  </div>
                      {!!Form::close()!!}
			      </div>
			      <div class="modal-footer">
			        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
			        <button type="button" class="btn btn-primary">Agregar</button>
			      </div>
			    </div>
			  </div>
			</div>
	  		<table class="table table-striped table-hover ">
	 			 <thead>
				    <tr>
				      <th>Nombre</th>
				      <th>Notificado</th>
				      <th>Asistira</th>
				      <th>Adultos</th>
				      <th>Niños</th>
				      <th>Costo</th>
				      <th>Gastos</th>
				      <th>Balance</th>
				      <th>$ ok</th>
				      <th>Acciones</th>
				    </tr>
	  			 </thead>
	  			<tbody>
				   <tr>
				      <td>- </td>
				      <td>- </td>
				      <td>- </td>
				      <td>- </td>
				      <td>- </td>
				      <td> -</td>
				      <td>- </td>
				      <td>- </td>
				      <td>- </td>
				      <td> -</td>
				    </tr>
				    <tr class="warning">
				      <td>- </td>
				      <td>- </td>
				      <td>- </td>
				      <td>- </td>
				      <td> -</td>
				      <td>- </td>
				      <td>- </td>
				      <td>- </td>
				      <td>- </td>
				      <td>- </td>
				    </tr>
			    </tbody>
			</table> <br> <br>
			<a href="#" class="btn btn-default">Enviar invitación a no notificados</a>
			<a href="#" class="btn btn-primary">Reenviar invitación a no confirmados</a>
			<a href="#" class="btn btn-success">Enviar cuentas a asistentes</a>
	  </fieldset> <br> <br>
	  <fieldset>
	  		@include('includes.cuentas')
	  </fieldset>  <br> <br>
	  <fieldset>
		  	<legend>Lista de compras</legend>
	  		<ul class="nav navbar-right">  
	 			<a href="#" class="btn btn-warning" data-toggle='modal' data-target='#popupNuevoItem'>Agregar item +</a><br><br>
			</ul>
			<div class="modal" id='popupNuevoItem' role='dialog'>
			  <div class="modal-dialog">
			    <div class="modal-content">
			      <div class="modal-header">
			        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			        <h4 class="modal-title">Nuevo Item</h4>
			      </div>
			      <div class="modal-body">
			        	{!!Form::open(array('method' => 'POST', 'url' => '/itempop', 'role' => 'form'))!!}
								<div class "row">
									<div class="col-lg-6">
										<div class="input-group" >
												{!!Form::label('Nombre del Item')!!}
												{!!Form::text('nombre','',array('class'=>'form-control'))!!} 
										</div>
									</div>
								</div> <br><br><br><br>
								<div class "row">
									<div class="col-lg-6">
										<div class="input-group" >
												{!!Form::label('Cantidad')!!}
												{!!Form::input('number','cantidad')!!} 
										</div>
									</div>
								</div>
								</br>
								
						{!!Form::close()!!}
			      </div>
			      <div class="modal-footer">
			        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
			        <button type="button" class="btn btn-primary">Agregar</button>
			      </div>
			    </div>
			  </div>
			</div>
	  		<table class="table table-striped table-hover ">
				  <thead>
				     <tr>
				       <th>que hace falta?</th>
				       <th>quien trae?</th>
				       <th>cuantos?</th>
				       <th>faltan</th>
				       <th>acciones</th>
				     </tr>
				  </thead>
				  <tbody>
					   <tr>
					      <td>- </td>
					      <td>- </td>
					      <td>- </td>
					      <td> -</td>
					      <td>- </td>
					    </tr>
					    <tr class="warning">
					      <td>- </td>
					      <td>- </td>
					      <td>- </td>
					      <td>- </td>
					      <td>- </td>
					    </tr>
				  </tbody>
			</table> 
			<a href="#" class="btn btn-default">Enviar lista de compras</a>
  	  </fieldset>  <br> <br>
  	  <fieldset>
		  <legend>Mensajes/log de actividades</legend>
		  <div class="container">
			 <div class="form-group">
			      <!--<label for="textArea" class="col-lg-2 control-label">Textarea</label> -->
			      <div class="col-lg-10">
			        <textarea class="form-control" rows="3" id="textArea"></textarea>
			        <span class="help-block"></span>
			      </div>
		     </div>
		     <div class="form-group">
			 	 <label class="control-label">Mensaje</label>
			 	 <div class="input-group col-lg-10">
				    
				    <input type="text" class="form-control">
				    <span class="input-group-btn">
			      		<button class="btn btn-default" type="button">Enviar</button>
			    	</span>
			  	 </div>
			 </div>
		  </div>
      </fieldset>  <br> <br>
	  <fieldset>
	  		<legend>Fotos</legend>
	  		<div id="links">
			    <a href="{{ asset('fb.jpg') }}"title="Banana" data-gallery>
			        <img src="{{ asset('img/fb.jpg') }}">
			    <a href="{{ asset('inst.jpg') }}" title="Apple" data-gallery>
			        <img src="{{ asset('img/inst.jpg') }}" alt="Apple">
			    </a>
			    <a href="{{ asset('tw.jpg') }}" title="Orange" data-gallery>
			        <img src="{{ asset('img/tw.jpg') }}" alt="Orange">
			    </a>
			</div>
	  		<!-- The Bootstrap Image Gallery lightbox, should be a child element of the document body -->
			<div id="blueimp-gallery" class="blueimp-gallery">
			    <!-- The container for the modal slides -->
			    <div class="slides"></div>
			    <!-- Controls for the borderless lightbox -->
			    <h3 class="title"></h3>
			    <a class="prev">‹</a>
			    <a class="next">›</a>
			    <a class="close">×</a>
			    <a class="play-pause"></a>
			    <ol class="indicator"></ol>
			    <!-- The modal dialog, which will be used to wrap the lightbox content -->
			    <div class="modal fade">
			        <div class="modal-dialog">
			            <div class="modal-content">
			                <div class="modal-header">
			                    <button type="button" class="close" aria-hidden="true">&times;</button>
			                    <h4 class="modal-title"></h4>
			                </div>
			                <div class="modal-body next"></div>
			                <div class="modal-footer">
			                    <button type="button" class="btn btn-default pull-left prev">
			                        <i class="glyphicon glyphicon-chevron-left"></i>
			                        Previous
			                    </button>
			                    <button type="button" class="btn btn-primary next">
			                        Next
			                        <i class="glyphicon glyphicon-chevron-right"></i>
			                    </button>
			                </div>
			            </div>
			        </div>
			    </div>
			</div>
			<div class="form-group">
				  <label class="control-label">Agregar foto</label>
				  <div class="input-group">
					    <input type="file" class="form-control">
					    <span class="input-group-btn">
					    	  <button class="btn btn-default" type="button">Subir</button>
					    </span> 
				  </div>
			</div>
	        <br><br><br>
	  </fieldset>
	{!!Form::close()!!}
</div>
@endsection
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA0x2gX3yarU-p7rLGjj7JUVBpxgSdmInk&libraries=places&callback=initAutocomplete"
         async defer></script>



         