<legend>Cuentas</legend>
	  		<div class="form-group">
	     		<div class="col-lg-5">
			        <div class="radio">
				         <!-- {!!Form::radio('rbCuentas', 'op1', array('id' =>'1' ,'onclick'=>'op1()'))!!}
				          {!!Form::label('rbCuentas','El organizador invita')!!}-->
				         <label >
				            <input type="radio" name="rbCuentas" id="1" value="option1" checked="" onclick='op1()' > 
				            El organizador invita
				        </label>    
			        </div>
	       			<div class="radio">
	       			 <!--	{!!Form::radio('rbCuentas', 'op2', array('id' =>'2' ,'onclick'=>'op2()'))!!}
				        {!!Form::label('rbCuentas','Se establece un valor fijo')!!}
			         -->  
			         <label>
				     
				        <input type="radio" name="rbCuentas" id="2" value="option2"   onclick='op2()'   >
				            Se establece un valor fijo
				        </label> 

			        </div>
			        <div class="radio">
			        	 <!-- {!!Form::radio('rbCuentas', 'op3', array('id' =>'3' ,'onclick'=>'op3()'))!!}
				          {!!Form::label('rbCuentas','Se establece un valor fijo por asistente')!!}
			          	   array('id' =>'3' ,'onclick'=>'opciones()'),(Input::old('rbCuentas') == 'op3') 
			          -->	
			            <label>
				            <input type="radio" name="rbCuentas" id="3" value="option3"  onclick='op3()' >
				            Se establece un valor fijo por asistente
				        </label> 
			        </div>
			        <div class="radio">
			        	<!--  {!!Form::radio('rbCuentas', 'op4', array('id' =>'4' ,'onclick'=>'op4()'))!!}
				          {!!Form::label('rbCuentas','Se divide lo gastado en partes iguales')!!}
			         	 -->
			           <label>
				            <input type="radio" name="rbCuentas" id="4" value="option4"  onclick='op4()' >
				            Se divide lo gastado en partes iguales
				        </label> 
			        </div>
			        <div class="radio">
			        	<!--   {!!Form::radio('rbCuentas', 'op5', array('id' =>'5' ,'onclick'=>'op5()'))!!}
				          {!!Form::label('rbCuentas','Se divide lo gastado segun asistentes')!!}
			          -->
			          	<label>
			          	    <input type="radio" name="rbCuentas" id="5" value="option5"  onclick='op5()' >
				            Se divide lo gastado segun asistentes
				        </label> 
			        </div>
			        <div class="radio">
			        	<!--   {!!Form::radio('rbCuentas', 'op6', array('id' =>'6' ,'onclick'=>'op6()'))!!}
				          {!!Form::label('rbCuentas','Se divide un valor arbitrario en partes iguales')!!}
			          	 -->
			          	 <label>
				            <input type="radio" name="rbCuentas" id="6" value="option6"  onclick='op6()' >
				            Se divide un valor arbitrario en partes iguales
				        </label>
			        </div>
			        <div class="radio">
			        	<!--  {!!Form::radio('rbCuentas', 'op7', array('id' =>'7' ,'onclick'=>'op7()'))!!}
				          {!!Form::label('rbCuentas','Se divide un valor arbitrario segun asistentes')!!}
			          	--> 
			          	<label>
				            <input type="radio" name="rbCuentas" id="7" value="option7"  onclick='op7()' >
				            Se divide un valor arbitrario segun asistentes
				        </label> 
			        </div>
	     		</div>
	     		<div class="col-lg-7 form-group" id='infoCuenta1'>
	     			<legend > No se hacen cuentas</legend>
	     		</div>
	     		<div class="col-lg-7 form-group" id='infoCuenta2' style="display:none;">
	     			<legend > Valor fijo para cada invitado</legend>
	     			<label class="control-label">Costo por persona:</label>
	     			<input type='text' class="form-control"></input><br><br>
	     			<div class="form-group navbar-right">
					      <div class="col-lg-10 col-lg-offset-2">
					        {!!Form::submit('Guardar', array('class' => 'btn btn-success')) !!}
					      </div>
		   			</div>
	     		</div>
	     		<div class="col-lg-7 form-group" id='infoCuenta3' style="display:none;">
	     			<legend > Valor fijo diferenciado segun Adulto-Niño</legend>
					<label class="control-label">Costo por Adulto:</label>
	     			<input type='text' class="form-control"></input> <br>
	     			<label class="control-label">Costo por Niño:</label>
	     			<input type='text' class="form-control"></input><br><br>
					<div class="form-group navbar-right">
			        <div class="col-lg-10 col-lg-offset-2">
			        	{!!Form::submit('Guardar', array('class' => 'btn btn-success')) !!}
			        </div>
			    </div>
	     		</div>
	     		<div class="col-lg-7 form-group" id='infoCuenta4' style="display:none;">
	     			<legend >Se divide lo gastado entre todos los invitados</legend>
	     			<label class="control-label">Total gastado:</label>
	     			<input type='text' class="form-control"></input> <br>
	     			<label class="control-label">Cantidad de invitados:</label>
	     			<input type='text' class="form-control"></input><br><br>
	     			<div class="form-group navbar-right">
			        <div class="col-lg-10 col-lg-offset-2">
			       		{!!Form::submit('Guardar', array('class' => 'btn btn-success')) !!}
			        </div>
			    </div>
	     		</div>
	     		<div class="col-lg-7 form-group" id='infoCuenta5' style="display:none;">
	     			<legend >Se divide lo gastado entre todos los asistentes</legend>
	     			<label class="control-label">Total gastado:</label>
	     			<input type='text' class="form-control"></input> <br>
	     			<label class="control-label">Cantidad de asistentes:</label>
	     			<input type='text' class="form-control"></input><br><br>
	     			<div class="form-group navbar-right">
			        <div class="col-lg-10 col-lg-offset-2">
			        	{!!Form::submit('Guardar', array('class' => 'btn btn-success')) !!}
			        </div>
			    </div>
	     		</div>
	     		<div class="col-lg-7 form-group" id='infoCuenta6' style="display:none;">
	     			<legend >Se divide un valor arbitrario entre todos los invitados</legend>
	     			<label class="control-label">Total estimado:</label>
	     			<input type='text' class="form-control"></input> <br>
	     			<label class="control-label">Cantidad de invitados:</label>
	     			<input type='text' class="form-control"></input><br><br>
	     			<div class="form-group navbar-right">
			        <div class="col-lg-10 col-lg-offset-2">
			        	{!!Form::submit('Guardar', array('class' => 'btn btn-success')) !!}
			        </div>
			    </div>
	     		</div>
	     		<div class="col-lg-7 form-group" id='infoCuenta7' style="display:none;">
	     			<legend>Se divide un valor arbitrario entre todos los asistentes</legend>
	     			<label class="control-label">Total estimado:</label>
	     			<input type='text' class="form-control"></input> <br>
	     			<label class="control-label">Cantidad de asistentes:</label>
	     			<input type='text' class="form-control"></input><br><br>
	     			<div class="form-group navbar-right">
			        <div class="col-lg-10 col-lg-offset-2">
			       	   {!!Form::submit('Guardar', array('class' => 'btn btn-success')) !!}
			        </div>
			    </div>
	     	</div>