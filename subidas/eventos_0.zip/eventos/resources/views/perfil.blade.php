@extends('admin.template.layout')
@section('title')
    Perfil
@endsection
@section('content')
	<div class="container">
		
			<legend>Mis datos</legend>
            <p>Nombre de usuario: <!-- {{Session::get('usuario_username')}} --> </p>
            <p>Email: <!-- {{Session::get('usuario_email')}} --> </p>     
       		<p>Etc: <!-- {{Session::get('usuario_email')}} --> </p>
			
    </div>
@endsection