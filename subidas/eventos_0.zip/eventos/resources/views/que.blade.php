@extends('admin.template.layout')
@section('title')
    Que es Eventos
@endsection
@section('content')
<div class="container">
    <legend> Qué es Eventos</legend>
  <div class="row">
        <div class="col-sm-6 col-md-4">
            <div class="thumbnail">
                <img src="{{ asset('img/cafe.jpg') }}" alt="...">
            </div>
        </div>
        <div class="col-sm-6 col-md-4">
           <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent facilisis egestas tortor et interdum. Nunc condimentum urna gravida, tincidunt augue ut, facilisis sapien. Maecenas posuere, felis vel ornare ultrices, metus nisi rutrum arcu, ac lacinia urna dui eget sem. Nulla orci lectus, laoreet at diam a, tempor blandit est. Aenean lobortis in lectus venenatis consequat. Mauris euismod ut turpis nec commodo. Phasellus mattis id odio eu euismod. Sed orci sem, aliquet cursus sem sed, convallis congue quam. In in leo aliquam, consequat urna sit amet, interdum arcu. Maecenas fermentum fermentum tellus id vestibulum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi iaculis ullamcorper felis a congue. Nulla pretium auctor ex in aliquam. Aenean efficitur mauris ac felis molestie, bibendum varius felis laoreet. Phasellus fringilla mauris non lacus viverra, at commodo magna ullamcorper.</p>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-6 col-md-4">
           <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent facilisis egestas tortor et interdum. Nunc condimentum urna gravida, tincidunt augue ut, facilisis sapien. Maecenas posuere, felis vel ornare ultrices, metus nisi rutrum arcu, ac lacinia urna dui eget sem. Nulla orci lectus, laoreet at diam a, tempor blandit est. Aenean lobortis in lectus venenatis consequat. Mauris euismod ut turpis nec commodo. Phasellus mattis id odio eu euismod. Sed orci sem, aliquet cursus sem sed, convallis congue quam. In in leo aliquam, consequat urna sit amet, interdum arcu. Maecenas fermentum fermentum tellus id vestibulum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi iaculis ullamcorper felis a congue. Nulla pretium auctor ex in aliquam. Aenean efficitur mauris ac felis molestie, bibendum varius felis laoreet. Phasellus fringilla mauris non lacus viverra, at commodo magna ullamcorper.</p>
        </div>
        <div class="col-sm-6 col-md-4">
            <div class="thumbnail">
                <img src="{{ asset('img/cafe.jpg') }}" alt="...">
            </div>
        </div>
    </div>
</div>
@endsection