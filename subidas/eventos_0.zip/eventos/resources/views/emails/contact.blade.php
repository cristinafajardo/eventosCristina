<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Document</title>
	</head>
	<body>
		<p><strong>Nombre:</strong>{!! $nombre !!} </p>
		<p><strong>Correo:</strong>{!! $Email !!} </p>
		<p><strong>Mensaje:</strong>{!! $consulta !!} </p>
	</body>
</html>