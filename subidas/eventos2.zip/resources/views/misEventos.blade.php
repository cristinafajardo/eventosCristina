@extends('admin.template.layout')
@section('title')
    Mis Eventos
@endsection
@section('content')
 @if(!Session::has('usuario_id'))
        @include('restringido')
 @else
	<h1>Mis Eventos</h1>
	<ul class="nav navbar-right">  
	  <a href="{{ url('organizaEvento') }}" class="btn btn-warning">Organizar evento +</a><br><br>
	</ul>
	<div class="container">
		 <table class="table table-striped table-hover ">
			  <thead>
			    <tr>
			      <th>ID</th>
			      <th>Nombre evento</th>
			      <th>Lugar</th>
			      <th>Fecha</th>
			      <th>Organizador</th>
			      <th>Acciones</th>
			    </tr>
			  </thead>
			 <tbody>
				<?php $eventoID=-1?> <!-- creo una variable y la inicializo. aca guardo el id del evento mas adelante -->
				@foreach ($registrados as $registrado) <!-- recorre la tabla de Usuarios registrados-->
	               @if ($registrado->idusuario == Session::get('usuario_id')) <!-- si el id del usuario registrado coincide con el id del usuario de la sesion -->
	                  <?php $eventoID= $registrado->idevento  ?><!-- asigna el id del evento a la var antes creada -->
	               @endif
	            @endforeach
		     	@foreach($eventosCreados as $evento) <!-- recorre la tabla de eventos-->
		      		@if ($evento->creador == Session::get('usuario_id') ) <!-- si el creador del evento es el mismo usuario de la sesion-->
                  		<?php $usuarios=\App\Usuario::find($evento->creador)?>
				   		   <tr>
				   		   	 <td>{{ $evento->id }}</td>
				   			 <td>{{ $evento->nombre }}</td>
				   			 <td>{{ $evento->direccion }}</td>
				   			 <td>{{ $evento->fecha }}</td>
				   			 <td>{{ $usuarios->username  }}</td>
				   			 <td>
				   				 <a href="{{ route('misEventos.edit', $evento->id) }}" class="btn btn-info" > 
		                         <span class="glyphicon glyphicon-zoom-in" ></span></button>
		                         <a href="{{ route('misEventos.destroy', $evento->id) }}" class="btn btn-danger" > 
		                         <span class="glyphicon glyphicon-trash"></span></a> 
				   			 </td>
				   		   </tr>
				 @endif
			    @endforeach
			    </tbody> 
		</table>  
	</div>
{!! $eventosCreados->render() !!}
		         
@endif
@endsection