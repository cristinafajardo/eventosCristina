<html>
<head>
    <script type="text/javascript">var centreGot = false;</script>{!!$map['js']!!}
</head>
<body>
    {!!$map['html']!!}
</body>
</html>