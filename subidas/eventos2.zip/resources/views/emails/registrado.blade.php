<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Document</title>
	</head>
	<body>
		<p>Hola <strong>{!! $username !!}</strong>! Te registraste en Eventos-cris.tk</p>
		<p><strong>Tu nombre de usuario:</strong> {!! $email !!} </p>
		<p><strong>Tu contraseña:</strong> {!! $pass !!} </p>
		<p>Ingresa a tu cuenta en el siguiente link: eventos-cris.tk/login </a>
		<p>Gracias por utilizar nuestros servicios!</p>
	</body>
</html>