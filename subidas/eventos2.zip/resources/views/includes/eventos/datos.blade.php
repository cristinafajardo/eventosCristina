<div class="form-group">
	 <label for="nombre" class="col-lg-2 control-label">Nombre del evento</label>
  <div class="col-md-10">
  	   {!!Form::text('nombre','', ['class' => 'form-control','required'])!!}
	   <span class="help-block">{{ $errors->first('nombre') }}</span>
  </div>
</div>
<div class="form-group">
	  <label for="lugar" class="col-lg-2 control-label">Lugar</label>
  <div class="col-md-10">
  	   {!!Form::text('lugar', '', ['class' => 'form-control','required'])!!}
	   <span class="help-block">{{ $errors->first('lugar') }}</span>
  </div>
</div>
<div class="form-group">
		{!!Form::label('Fecha','',array('class'=>'col-lg-2 control-label'))!!}
	<div class="col-lg-10">
	{!! Form::input('date','fecha','',array( 'date_format' => 'yyyy-mm-dd')) !!}
	<!--Form::text('fecha','',array('class'=>'form-control','class'=>'input-append date','data-date-format'=>'dd-mm-yyyy'))-->
	</div>
	
</div>	
<div class="form-group">
		{!!Form::label('Hora','',array('class'=>'col-lg-2 control-label'))!!}
	<div class="col-lg-10">
		{!! Form::input('time', 'hora','',array( 'time_format' => 'HH:mm:ss')) !!}
		<!--Form::text('hora','',array('class'=>'form-control')) -->
	</div>
</div>	
<div class="form-group">
	  <label for="descripcion" class="col-lg-2 control-label">Descripción del evento</label>
  <div class="col-md-10">
  	   {!!Form::textarea('descripcion', '', ['class' => 'form-control','required'])!!}
	   <span class="help-block">{{ $errors->first('descripcion') }}</span>
  </div>
<!--  <label for="textArea" class="col-lg-2 control-label">Descripcion del evento</label>
 <div class="col-lg-10">
   <textarea class="form-control" rows="3" id="textArea"></textarea>
   <span class="help-block"></span>
 </div> -->
</div>
<div class="form-group">
	  <label for="mayores" class="col-lg-2 control-label">Adultos</label>
  <div class="col-md-2">
  	   {!!Form::number('mayores','', ['class' => 'form-control','required', 'min'=>'0'])!!}
	   <span class="help-block">{{ $errors->first('descripcion') }}</span>
  </div>
  <label for="menores" class="col-lg-2 control-label">Niños</label>
  <div class="col-md-2">
  	   {!!Form::number('menores', '', ['class' => 'form-control','required', 'min'=>'0'])!!}
	   <span class="help-block">{{ $errors->first('descripcion') }}</span>
  </div>
</div>