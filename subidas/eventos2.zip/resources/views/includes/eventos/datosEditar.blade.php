{!!Form::open(['route'=> ['misEventos.update',$evento], 'method' => 'PUT', 'class' => 'form-horizontal'])!!}
	<div class="form-group">
		 <label for="nombre" class="col-lg-2 control-label">Nombre del evento</label>
	  <div class="col-md-10">
	  	   {!!Form::text('nombre', $evento->nombre, ['class' => 'form-control','required'])!!}
		   <span class="help-block">{{ $errors->first('nombre') }}</span>
	  </div>
	</div>
	<div class="form-group">
		  <label for="lugar" class="col-lg-2 control-label">Lugar</label>
	  <div class="col-md-10">
	  	   {!!Form::text('lugar', $evento->direccion, ['class' => 'form-control','required'])!!}
		   <span class="help-block">{{ $errors->first('lugar') }}</span>
	  </div>
	</div>
	<div class="form-group">
			{!!Form::label('Fecha','',array('class'=>'col-lg-2 control-label'))!!}
		<div class="col-lg-10">
		{!! Form::input('date','fecha',$evento->fecha, ['date_format' => 'yyyy-mm-dd']) !!}
		<!--Form::text('fecha','',array('class'=>'form-control','class'=>'input-append date','data-date-format'=>'dd-mm-yyyy'))-->
		</div>
		
	</div>	
	<div class="form-group">
			{!!Form::label('Hora','',array('class'=>'col-lg-2 control-label'))!!}
		<div class="col-lg-10">
			{!! Form::input('time', 'hora',$evento->hora,['time_format' => 'HH:mm:ss']) !!}
			<!--Form::text('hora','',array('class'=>'form-control')) -->
		</div>
	</div>	
	<div class="form-group">
		  <label for="descripcion" class="col-lg-2 control-label">Descripción del evento</label>
	  <div class="col-md-10">
	  	   {!!Form::textarea('descripcion', $evento->descripcion, ['class' => 'form-control','required'])!!}
		   <span class="help-block">{{ $errors->first('descripcion') }}</span>
	  </div>
	</div>
	<div class="form-group">
		  <label for="mayores" class="col-lg-2 control-label">Adultos</label>
	  <div class="col-md-2">
	  	   {!!Form::number('mayores', $evento->adultosmax, ['class' => 'form-control','required', 'min'=>'0'])!!}
		   <span class="help-block">{{ $errors->first('descripcion') }}</span>
	  </div>
	  <label for="menores" class="col-lg-2 control-label">Niños</label>
	  <div class="col-md-2">
	  	   {!!Form::number('menores', $evento->menoresmax, ['class' => 'form-control','required', 'min'=>'0'])!!}
		   <span class="help-block">{{ $errors->first('descripcion') }}</span>
	  </div>
	</div>
<!-- GMAPS -->
	<div  class="form-group">
		  <label class="col-lg-2 control-label"></label>
	  <div class="col-md-10">
	  	  <p><strong>Arrastrar el marcador para seleccionar ubicación</p></strong> 				   
	  </div>
	   @include('includes.eventos.mapahdp') 
	</div>
	<div class="form-group">
	  <div class="col-lg-10 col-lg-offset-2">
	    {!!Form::submit('Editar datos',['id'=>'editarEvento','class' => 'btn btn-primary'])!!}
	  </div>
	</div>
 {!!Form::close()!!}