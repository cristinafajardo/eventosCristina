<legend>Invitados</legend>
<div class="checkbox">
  <label>
    <input type="checkbox" id='listaCerrada' onClick="cerrado();"> Lista cerrada
  </label>
</div>
<ul class="nav navbar-right">  
	<a href="app/views/includes/eventos" class="btn btn-info" data-toggle='modal' data-target='#popupNuevoInvitado' id='+invitado'>Agregar invitado +</a><br><br><br>
</ul>
<div class="modal" id='popupNuevoInvitado' role='dialog'>
  <div class="modal-dialog">
	    <div class="modal-content">
		      <div class="modal-header">
			        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			        <h4 class="modal-title">Nuevo Invitado</h4>
		      </div>
		      <div class="modal-body">
		      {!!Form::open(['method' => 'POST', 'url' => '/invitados', 'role' => 'form'])!!}
					 <div class="form-group">
	                     <label for="nombreinvitado" class="col-lg-2 control-label">Nombre: </label> 
	                     <div class="col-lg-8">
	                     	{!!Form::text('nombreinvitado','',['class'=>'form-control col-md-10', 'placeholder'=>'Ej: Spiderman'])!!}
	                    	<!--  <input class="form-control col-md-10" id="inputNombre" placeholder="Nombre" type="text" name="nombreinvitado">  -->
	                	 </div><br><br><br>
	                 </div>
					 <div class="form-group">
	                     <label for="mail" class="col-lg-2 control-label">Email:</label>
	                     <div class="col-lg-8">   
	                         {!!Form::email('mail', '', ['class' => 'form-control','placeholder'=>'example@mail.com','required'])!!}
	                        <!-- <input class="form-control col-md-10" id="inputEmail" placeholder="Email del invitado" type="email" name="mail"> -->
	                     </div>                
	                 </div><br><br> 
					 <div class="form-group"><br><br> 
						<label class="col-lg-2 control-label">ROL:</label>
							<div class="col-lg-2">
							    <label class="radio-inline">
								<input type="radio" name="rol" value="invitado" checked="checked">Invitado</label>
					        </div>
						    <div class="col-lg-2">
						       <label class="radio-inline">
						       <input type="radio" name="rol" value="creador">Organizador</label>
	            	        </div>
	            	  </div><br><br> 
                
		      </div>
		      <div class="modal-footer">
		         <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
		         {!!Form::submit('Agregar',['id'=>'agregarinvitado','class' => 'btn btn-primary'])!!}
		      </div> 
		      {!!Form::close()!!}
	    </div>
  </div>
</div>
<table class="table table-striped table-hover ">
	<thead>
	    <tr>
	      <th>Nombre</th>
	      <th>Adultos</th>
	      <th>Niños</th>
	      <th>Notificado</th>
	      <th>Asistirá</th>
	      <th>Costo</th>
	      <th>Gastos</th>
	      <th>Balance</th>
	      <th>Acciones</th> 
	    </tr>
	</thead>
	<tbody>
	 	  <tr>
			 <td></td>
			 <td></td>
			 <td></td>
			 <td></td>
			 <td></td>
			 <td></td>
			 <td></td>
		     <td></td>
		   	 <td>
		   		 <a href="" class="btn btn-success" > Reenviar invitación
		         <a href="" class="btn btn-danger" > 
		         <span class="glyphicon glyphicon-trash"></span></a> 
		   	 </td>
		  </tr>		   
	</tbody>
</table>
<br> <br>
<a href="#" class="btn btn-default">Enviar invitación a no notificados</a>
<a href="#" class="btn btn-primary">Reenviar invitación a no confirmados</a>
<a href="#" class="btn btn-success">Enviar cuentas a asistentes</a>