<legend>Lista de compras</legend>
<ul class="nav navbar-right">  
	<a href="app/views/includes/eventos" class="btn btn-info" data-toggle='modal' data-target='#popupNuevoItem' id='+item'>Agregar item +</a><br><br><br>
</ul>
<div class="modal" id='popupNuevoItem' role='dialog'>
  <div class="modal-dialog">
	    <div class="modal-content">
		      <div class="modal-header">
			        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			        <h4 class="modal-title">Nuevo Item</h4>
		      </div>
		      <div class="modal-body">
			      	{!!Form::open(['method' => 'POST', 'url' => '/compras', 'role' => 'form', 'action' =>'ItemsController@store'])!!}
			      	     <label for="inputArticulo" class="col-lg-2 control-label">Artículo:</label> 
	                     <div class="col-lg-8">
	                     	{!!Form::text('nombrearticulo','',['class'=>'form-control col-md-10', 'placeholder'=>'Ej: Pan'])!!}
	                    	<!--  <input class="form-control col-md-10" id="inputArticulo" placeholder="Nombre" type="text" name="nombrearticulo">  -->
	                	 </div><br><br><br>
	                     <label for="cantidad" class="col-lg-2 control-label">Cantidad:</label>
	                     <div class="col-lg-8">   
	                     	{!!Form::number('cantidad', '', ['class' => 'form-control col-md-10"','min'=>'0'])!!}
	                        <!-- <input class="form-control col-md-10" id="inputCantidad" placeholder="Cantidad necesaria" type="number" name="cantidad" min="0"> -->
	                     </div>                
	                
		      </div> <br><br> 
		      <div class="modal-footer">
		         <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
		          {!!Form::submit('Agregar',['id'=>'agregaritem','class' => 'btn btn-primary'])!!} 
		          {!!Form::close()!!} 
		      </div>
	    </div>
  </div>
</div>
<table class="table table-striped table-hover ">
<thead>
   <tr>
       <th>Qué hace falta?</th>
       <th>Quien trae?</th>
       <th>Cuántos?</th>
       <th>Faltan</th>
       <th>Acciones</th>
   </tr>
</thead>
<tbody>
	
		   <tr>
		      <td>  </td>
		      <td>  </td>
		      <td>  </td>
		      <td>  </td>
		      <td>
		      	 <a href="" class="btn btn-success" > Llevar
				 <a href="" class="btn btn-warning" > Asignar
				 <a href="" class="btn btn-danger" > 
				 <span class="glyphicon glyphicon-trash"></span></a>
		      </td>
		   </tr>
</tbody>
</table> 
<a href="#" class="btn btn-default">Enviar lista de compras</a>