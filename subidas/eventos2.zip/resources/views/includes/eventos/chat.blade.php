<legend>Mensajes/log de actividades</legend>
<div class="container">
	 <div class="form-group">
	      <!--<label for="textArea" class="col-lg-2 control-label">Textarea</label> -->
	      <div class="col-lg-10">
	        <textarea class="form-control" rows="3" id="textArea"></textarea>
	        <span class="help-block"></span>
	      </div>
     </div>
     <div class="form-group">
	 	 <label class="control-label">Mensaje</label>
	 	 <div class="input-group col-lg-10">
		     <input type="text" class="form-control">
		     <span class="input-group-btn">
	      	    <button class="btn btn-default" type="button">Enviar</button>
	    	 </span>
	  	 </div>
	 </div>
</div>