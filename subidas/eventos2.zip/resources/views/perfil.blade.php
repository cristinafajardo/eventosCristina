@extends('admin.template.layout')
@section('title')
    Perfil
@endsection
@section('content')
    @if(!Session::has('usuario_id'))
        @include('restringido')
    @else
    	<legend>Mis datos</legend>
      <div class="jumbotron">
          <p><strong>Nombre de usuario:</strong>  {{Session::get('usuario_username')}}  </p>
          <p><strong>Email:</strong> {{Session::get('usuario_email')}}  </p>     
          <p><strong>Provincia:</strong> {{Session::get('usuario_pcia')}}  </p>
         	<p><strong>Ciudad:</strong> {{Session::get('usuario_city')}}  </p> 
    	</div>
    @endif
@endsection