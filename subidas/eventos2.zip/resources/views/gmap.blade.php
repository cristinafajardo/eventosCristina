<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
     <link href="{{ asset('css/gmapStyle.css') }}" rel="stylesheet" type="text/css">
    <title>Places Searchbox</title>
    <style>
      #target {
        width: 345px;
      }
    </style>
  </head>
  <body>
    <input id="pac-input" class="controls" type="text" placeholder="Search Box">
    <div id="map"></div>
    <script type="text/javascript" src="{{ asset('js/gmapJs.js') }}"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBDAyzyYpPe31ZhJZns5wif4pFJB7Wxjzo&libraries=places&callback=initAutocomplete"
         async defer></script>
  </body>
</html>