<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Redirect;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Input;
use DB;
use Validator;
use App\Usuario;
use App\Evento;


class EventosController extends Controller
{
    /**$miseventos = \App\Evento::paginate(5);
        return view('misEventos',compact('miseventos'));

     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()

    {
        $eventosCreados = \App\Evento::paginate(10);//guardo en $eventosCreados todas las filas de la tabla eventos
        $registrados = \App\Usuario::all(); //guardo en $registrados todos los usuarios registrados
        return View('misEventos',array('eventosCreados'=>$eventosCreados,'registrados'=>$registrados)); //devuelve la vista de MisEventos con el valor 'lista de eventos'
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         \App\Evento::create([
                'nombre' => $request['nombre'],
                'direccion' => $request['lugar'],
                'fecha' =>$request['fecha'],
                'hora' => $request['hora'],
                'descripcion' => $request['descripcion'],
                'latitud' => '-41.133472', //$request['lat'],
                'longitud' => '-71.310278',//$request['long'],
                'cerrado' => $request['ciudad'],
                'metodocuenta' => $request['ciudad'],
                'menoresmax' => $request['menores'],
                'adultosmax' => $request['mayores'],
                'creador' => session('usuario_id'),
            ]);
            /* $registrados = \App\Usuario::all();
             $eventosCreados = \App\Evento::paginate(6);
             return view('misEventos',array('eventosCreados'=>$eventosCreados,'registrados'=>$registrados));*/
             return Redirect::action('EventosController@index');
            
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $evento=\App\Evento::find($id);
        return view('includes.eventos.editarEvento')->with('evento',$evento);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
                $evento=\App\Evento::find($id);
                $evento->nombre = $request['nombre'];
                $evento->direccion = $request['lugar'];
                $evento->fecha = $request['fecha'];
                $evento->hora = $request['hora'];
                $evento->descripcion = $request['descripcion'];
                //$evento->latitud -> '-41.133472'; //$request['lat'],
                //$evento->longitud -> '-71.310278';//$request['long'],
                $evento->cerrado = $request['ciudad'];
                $evento->metodocuenta = $request['ciudad'];
                $evento->menoresmax = $request['menores'];
                $evento->adultosmax = $request['mayores'];
                $evento->creador = session('usuario_id');
                $evento->save();
               // return Redirect::to('perfil');
               /* $registrados = \App\Usuario::all();
                $eventosCreados = \App\Evento::paginate(6);
                return redirect::route('misEventos.index',array('eventosCreados'=>$eventosCreados,'registrados'=>$registrados));*/
                return Redirect::action('EventosController@index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        \App\Evento::destroy($id);
        //Session::flash('message','Usuario Eliminado Correctamente');
        return Redirect::to('misEventos');
    }
}
