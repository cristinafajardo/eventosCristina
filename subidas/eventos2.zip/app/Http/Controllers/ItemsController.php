<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;
use Redirect;
use Input;
use DB;
use Validator;
use App\Usuario;
use App\Evento;
use App\Item;


class ItemsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $eventosCreados = \App\Evento::paginate(6);//guardo en $eventosCreados todas las filas de la tabla eventos
        $items = \App\Item::all(); //guardo en $items todos los items cargados
        return View('compras',array('eventosCreados'=>$eventosCreados,'items'=>$items)); //devuelve la vista de MisEventos con el valor 'lista de eventos'
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    


    public function store(Request $request)
    {
        //
         \App\Item::create([
                'idevento' => '55',
                'nombre' => $request['nombrearticulo'],
                'cantidad' =>$request['cantidad']
                
            ]);
         return redirect('que');// CAMBIAR ESTO PARA VOLVER AL MISMO EVENTO CON IDEVENTO
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
