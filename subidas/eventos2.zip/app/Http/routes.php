<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/*VISTAS SIN FUNCIONALIDAD */
Route::get('/', 'DescripcionesController@index');/*INDEX */
Route::get('que', 'DescripcionesController@que');/*QUE ES */
Route::get('quienes', 'DescripcionesController@quienes');/*QUIENES SOMOS */
Route::get('contacto', 'DescripcionesController@contacto');/*CONTACTO */



/*REGISTRO */
Route::get('registro', 'UsuariosController@create');//muestra la vista de registro de usuario
Route::get('conf_reg','UsuariosController@conf_reg');
Route::post('registro', 'UsuariosController@store'); //guardo el usuario nuevo en bd
Route::resource('mail', 'MailController@store'); //envia mail de confirmacion de registro

/*LOGIN */
Route::get('login', 'UsuariosController@login');//MUESTRA LA VISTA CON FORM DE LOGIN
Route::post('login','UsuariosController@post_login'); //ENVIA LOS DATOS DEL USUARIO
Route::get('logout', 'UsuariosController@logout'); //CIERRA LA SESION
Route::get('perfil', 'UsuariosController@perfil'); //MUESTRA PERFIL DEL USUARIO

/*ORGANIZA EVENTO */
Route::get('organizaEvento', function () {
    return view('organizaEvento');
});
Route::post('organizaEvento', 'EventosController@store');//ENVIA DAROS DE EVENTO NUEVO A BD

/*MIS EVENTOS */
Route::resource('misEventos', 'EventosController');
Route::get('misEventos', 'EventosController@index');//LISTA EVENTOS DEL USUARIO
Route::get('misEventos/{id}/destroy', [
'uses' => 'EventosController@destroy',
'as' => 'misEventos.destroy']

);
//Route::get('misEventos/{id}/edit', []);


/**Google maps*/
//Route::get('/gmaps', ['as ' => 'gmaps', 'uses' => 'GmapsController@index']);

Route::get('mapahdp', function () {
    return view('mapahdp');
});
 //route::post(itempop, controller--->aca pongo la funcion de insertar)


Route::resource('upfotos','FotosController');

Route::resource('compras','ItemsController');
//Route::post('compras', 'ItemsController@store');
Route::resource('invitados','InvitadosController');