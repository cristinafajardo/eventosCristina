function op1()
{		document.getElementById('infoCuenta1').style.display="";
   		document.getElementById('infoCuenta2').style.display="none";
		document.getElementById('infoCuenta3').style.display="none";
		document.getElementById('infoCuenta4').style.display="none";
		document.getElementById('infoCuenta5').style.display="none";
		document.getElementById('infoCuenta6').style.display="none";
		document.getElementById('infoCuenta7').style.display="none";
	
}

function op2()
{ 		document.getElementById('infoCuenta2').style.display="";
		document.getElementById('infoCuenta1').style.display="none";
		document.getElementById('infoCuenta3').style.display="none";
		document.getElementById('infoCuenta4').style.display="none";
		document.getElementById('infoCuenta5').style.display="none";
		document.getElementById('infoCuenta6').style.display="none";
		document.getElementById('infoCuenta7').style.display="none";
	
}

function op3()
{		document.getElementById('infoCuenta3').style.display="";
		document.getElementById('infoCuenta1').style.display="none";
		document.getElementById('infoCuenta2').style.display="none";
		document.getElementById('infoCuenta4').style.display="none";
		document.getElementById('infoCuenta5').style.display="none";
		document.getElementById('infoCuenta6').style.display="none";
		document.getElementById('infoCuenta7').style.display="none";
	
}
	
function op4()
{		document.getElementById('infoCuenta4').style.display="";
		document.getElementById('infoCuenta1').style.display="none";
		document.getElementById('infoCuenta2').style.display="none";
		document.getElementById('infoCuenta3').style.display="none";
		document.getElementById('infoCuenta5').style.display="none";
		document.getElementById('infoCuenta6').style.display="none";
		document.getElementById('infoCuenta7').style.display="none";
	
}

function op5()
{		document.getElementById('infoCuenta5').style.display="";
		document.getElementById('infoCuenta1').style.display="none";
		document.getElementById('infoCuenta2').style.display="none";
		document.getElementById('infoCuenta3').style.display="none";
		document.getElementById('infoCuenta4').style.display="none";
		document.getElementById('infoCuenta6').style.display="none";
		document.getElementById('infoCuenta7').style.display="none";
	
}

function op6()
	{	document.getElementById('infoCuenta6').style.display="";
		document.getElementById('infoCuenta1').style.display="none";
		document.getElementById('infoCuenta2').style.display="none";
		document.getElementById('infoCuenta3').style.display="none";
		document.getElementById('infoCuenta4').style.display="none";
		document.getElementById('infoCuenta5').style.display="none";
		document.getElementById('infoCuenta7').style.display="none";
	
}

function op7()
{ 		document.getElementById('infoCuenta7').style.display="";
		document.getElementById('infoCuenta1').style.display="none";
		document.getElementById('infoCuenta2').style.display="none";
		document.getElementById('infoCuenta3').style.display="none";
		document.getElementById('infoCuenta4').style.display="none";
		document.getElementById('infoCuenta5').style.display="none";
		document.getElementById('infoCuenta6').style.display="none";	
}
