function cerrado()
{
	if (document.getElementById('listaCerrada').checked == true)
	{	
		document.getElementById('+invitado').style.display="none";
	}
	else
		document.getElementById('+invitado').style.display="";
}

function aceptar()
{
	if (document.getElementById('ok').checked)
	{	
		$('#Registrarme').attr("disabled", true);
	}
	else
		$('#Registrarme').attr("disabled", false);
}

function editar()
{
	document.getElementById('edicion').attr("disabled", false);
}